const AWS = require('aws-sdk');
const fs = require('fs');

const BUCKET_NAME = 'test-turnthebus-upload';

const s3bucket = new AWS.S3({
  accessKeyId: 'AKIAJDIDCWJIC5L6ABBA',
  secretAccessKey: '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'
});

const uploadToS3 = (fileName) => {
  const readStream = fs.createReadStream(fileName);

  const params = {
    Bucket: BUCKET_NAME,
    Key: 'myapp' + '/' + fileName,
    Body: readStream
  };

  return new Promise((resolve, reject) => {
    s3bucket.upload(params, function(err, data) {
      readStream.destroy();
      
      if (err) {
        return reject(err);
      }
      
      return resolve(data);
    });
  });
}

module.exports = {
  uploadToS3
};